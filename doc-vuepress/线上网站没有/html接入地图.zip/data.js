var data = [
    { value: 20, name: "云南" },
    { value: 10, name: "北京" },
    { value: 50, name: "山东" },
    { value: 40, name: "河北" },
    { value: 60, name: "江苏" },
    { value: 70, name: "浙江" },
    { value: 80, name: "四川" },
    { value: 90, name: "湖北" },
    { value: 100, name: "广西" },
]